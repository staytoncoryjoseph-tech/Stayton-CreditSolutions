// Stayton Credit Solutions - script.js
window.addEventListener('load',()=>{
  console.log('Stayton Credit Solutions script loaded successfully.');
  document.body.insertAdjacentHTML('beforeend','<p style="color:#003566;font-weight:bold;">JS is active!</p>');
});